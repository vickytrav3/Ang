
function IsCurrentUserWithContributePerms() 
{
    
  IsCurrentUserMemberOfGroup("MVSHR", function (isCurrentUserInGroup) {
      if (!isCurrentUserInGroup && document.URL.toLowerCase().indexOf("app.aspx")==-1)
    {
         // location.href = "https://multiverse.sharepoint.com/SitePages/App.aspx";
          //alert("You do not have access to this page.");
    }

  });

}
$(document).ready(function () { ExecuteOrDelayUntilScriptLoaded(IsCurrentUserWithContributePerms, "sp.js"); });


function IsCurrentUserMemberOfGroup(groupName, OnComplete) {
 
        var context = new SP.ClientContext.get_current();
        var currentWeb = context.get_web();
 
        var currentUser = context.get_web().get_currentUser();
        context.load(currentUser);
 
        var allGroups = currentWeb.get_siteGroups();
        context.load(allGroups);
 
        var group = allGroups.getByName(groupName);
        context.load(group);
        
        var groupUsers = group.get_users();
        context.load(groupUsers);
 
        context.executeQueryAsync(
                function(sender, args) {
                   var userInGroup = IsUserInGroup(currentUser,group);         
                   OnComplete(userInGroup);
                },
                function OnFailure(sender, args) {
                   OnComplete(false);
                }
        );
        
        function IsUserInGroup(user,group)
        {
            var groupUsers = group.get_users();
            var userInGroup = false;
            var groupUserEnumerator = groupUsers.getEnumerator();
            while (groupUserEnumerator.moveNext()) {
                var groupUser = groupUserEnumerator.get_current();
                if (groupUser.get_id() == user.get_id()) {
                    userInGroup = true;
                    break;
                }
            }
            return userInGroup;
        }
}