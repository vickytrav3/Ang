﻿"use strict";
(function () {
    angular.module(Config['AppName'])
        .factory("ApproverAction", ["baseSvc", "$q", function (baseService, $q) {


            var Action = function (ActionName, MasterId, TaskId, MasterListName, TaskListName, Comment, AssignedToUser,ApproverAmount) {

                var deferred = $q.defer();
                if (ActionName != undefined && ActionName != "") {
                    if (ActionName == "Accept")
                        var query = Config['ListEndPoint'] + "/GetByTitle('" + TaskListName + "')/Items?$select=*&$filter=ID eq " + TaskId + " and AssignedToUserId eq null &$top=4000";
                    else
                        var query = Config['ListEndPoint'] + "/GetByTitle('" + TaskListName + "')/Items?$select=*&$filter=ID eq " + TaskId + " and Status eq 'Pending' and  AssignedToUserId eq " + _spPageContextInfo.userId + " &$top=1";
                    baseService.getRequest(query).then(function (response) {
                        if (response.value.length > 0) {

                            var Taskdata = {};
                            var Masterdata = {};
                            if (ActionName == 'Accept') {

                                Taskdata = {
                                    __metadata: { 'type': 'SP.Data.' + TaskListName + 'ListItem' },
                                    AssignedToUserId: _spPageContextInfo.userId
                                }

                                Masterdata = {
                                    __metadata: { 'type': 'SP.Data.' + MasterListName + 'ListItem' },
                                    AssignedToUserId: _spPageContextInfo.userId,
                                    RecievedDate: new Date()
                                }

                            }
                            else if (ActionName == 'Forward') {

                                Taskdata = {
                                    __metadata: { 'type': 'SP.Data.' + TaskListName + 'ListItem' },
                                    Status: 'Approved',
                                    Comment: Comment
                                }

                                Masterdata = {
                                    __metadata: { 'type': 'SP.Data.' + MasterListName + 'ListItem' },
                                    LevelStatus: 'Approved'
                                }

                                if (MasterListName == 'NFAOthers') {
                                    if (AssignedToUser != undefined && AssignedToUser!=null && typeof (AssignedToUser) != 'number') {
                                        Taskdata.AdditionalApproverId = {
                                            '__metadata': { type: 'Collection(Edm.Int32)' },
                                            'results': AssignedToUser
                                        };
                                        Masterdata.AdditionalApproverId = {
                                            '__metadata': { type: 'Collection(Edm.Int32)' },
                                            'results': AssignedToUser
                                        };
                                    }
                                }
                                else {
                                    if (AssignedToUser != undefined && AssignedToUser != null && typeof (AssignedToUser) == 'number') {
                                        Taskdata.DelegatedUserId = AssignedToUser;
                                    }

                                    if (ApproverAmount != undefined && ApproverAmount != null && typeof (ApproverAmount) == 'number' && ApproverAmount!='') {
                                        Taskdata.ApproverAmount = ApproverAmount;
                                        Masterdata.ApproverAmount = ApproverAmount;
                                    }
                                }


                            }
                            else if (ActionName == 'Reject') {

                                Taskdata = {
                                    __metadata: { 'type': 'SP.Data.' + TaskListName + 'ListItem' },
                                    Status: 'Rejected',
                                    Comment: Comment
                                }

                                Masterdata = {
                                    __metadata: { 'type': 'SP.Data.' + MasterListName + 'ListItem' },
                                    LevelStatus: 'Rejected'
                                }

                                if (ApproverAmount != undefined && ApproverAmount != null && typeof (ApproverAmount) == 'number' && ApproverAmount != '') {
                                    Taskdata.ApproverAmount = ApproverAmount;
                                    Masterdata.ApproverAmount = ApproverAmount;
                                }
                            }
                            else if (ActionName == 'Delegate') {

                                Taskdata = {
                                    __metadata: { 'type': 'SP.Data.' + TaskListName + 'ListItem' },
                                    Status: 'Delegated',
                                    Comment: Comment,
                                    DelegatedUserId: AssignedToUser,
                                }

                                Masterdata = {
                                    __metadata: { 'type': 'SP.Data.' + MasterListName + 'ListItem' },
                                    LevelStatus: 'Delegated'
                                }
                                if (ApproverAmount != undefined && ApproverAmount != null && typeof (ApproverAmount) == 'number' && ApproverAmount != '') {
                                    Taskdata.ApproverAmount = ApproverAmount;
                                    Masterdata.ApproverAmount = ApproverAmount;
                                }
                            }

                            var queryTask = Config['ListEndPoint'] + "/GetByTitle('" + TaskListName + "')/GetItemById(" + TaskId + ")";
                            baseService.updateRequest(Taskdata, queryTask).then(function (response) {
                                var queryMaster = Config['ListEndPoint'] + "/GetByTitle('" + MasterListName + "')/GetItemById(" + MasterId + ")";
                                baseService.updateRequest(Masterdata, queryMaster).then(function (response) {
                                    deferred.resolve("success");
                                }).catch(function () {
                                    deferred.resolve("Something went wrong!!!.");
                                });
                            }).catch(function () {
                                deferred.resolve("Something went wrong!!!.");
                            });

                        } else {
                            deferred.resolve("Already Action Taken!!!.");
                        }
                    }).catch(function () {
                        deferred.resolve("Something went wrong!!!.");
                    });
                }
                else {
                    deferred.resolve("Something went wrong!!!.");
                }
                return deferred.promise;
            };

            return {
                Action: Action
            };
        }])
})();