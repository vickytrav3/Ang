﻿"use strict";
(function () {
    angular.module(Config['AppName'])
	.factory("FolderSvc", ["$q", "$http", function ($q, $http) {
	    var hostWebUrl = Config['BaseUrl'] + "/_api/lists/";
	    var updateThroughAPI = function (url, action, data) {
	        var model = {
	            Url: url,
	            Action: action
	        }
	        if (data == undefined || data == null) {
	            data = {};
	        }

	        //data["UpdatedById"] = _spPageContextInfo.userId;
	        model["Data"] = "";//JSON.stringify(data);

	        var deferred = $q.defer();
	        $http({
	            url: Config['BaseAPIUrl'] + 'SPRequest/Process',
	            method: "POST",
	            headers: {
	                "accept": "application/json;odata=verbose",
	                "content-Type": "application/json;odata=verbose"
	            },
	            data: model
	        })
            .success(function (response) {
                deferred.resolve('success');
            })
            .error(function (result, status) {
                deferred.reject(result);
            });
	        return deferred.promise;
	    };

	    var CreateFolder = function (DocLibName, mainFolder) {
	        var url = hostWebUrl + "/getByTitle('" + DocLibName + "')/rootfolder/folders/add(url=\'" + mainFolder.trim() + "\')";
	        if (Config.UseAPIForSPCall) {
	            return this.updateThroughAPI(url, 'POST');
	        }

	        var differed = $q.defer();
	        $.ajax({
	            url: url,
	            type: 'POST',
	            contentType: 'application/json;odata=verbose',
	            headers: {
	                'Accept': 'application/json;odata=verbose',
	                'content-type': 'application/json;odata=verbose',
	                'X-RequestDigest': $('#__REQUESTDIGEST').val()
	            },
	            success: function (data) { differed.resolve('success'); },
	            error: function () {
	                differed.reject("error");
	            }
	        });
	        return differed.promise;
	    };

	    var CreateSubFolder = function (DocLibName, mainFolder, subFolderName) {
	        var url = hostWebUrl + "/getByTitle('" + DocLibName + "')/rootfolder/Folders('" + mainFolder.trim() + "')/folders/add(url=\'" + subFolderName.trim() + "\')";
	        if (Config.UseAPIForSPCall) {
	            return this.updateThroughAPI(url, 'POST');
	        }
	        var differed = $q.defer();
	        $.ajax({
	            url: url,
	            type: 'POST',
	            contentType: 'application/json;odata=verbose',
	            headers: {
	                'Accept': 'application/json;odata=verbose',
	                'content-type': 'application/json;odata=verbose',
	                'X-RequestDigest': $('#__REQUESTDIGEST').val()
	            },
	            success: function (data) { differed.resolve('success'); },
	            error: function () {
	                differed.reject("error");
	            }
	        });
	        return differed.promise;
	    };

	    var CreateFolderByPath = function (path,MainFolder) {
	        var differed = $q.defer();
	        var PathArr = path.split('/');
	        var PathArray = [];
	        var Url = "";
	        for (var i = 0; i < PathArr.length; i++) {
	            if (PathArr[i] != undefined && PathArr[i].toString() != "") {
	                var Url = Url + "/" + PathArr[i].toString()
	                PathArray.push(Url);
	            }
	        }

	        CreateFolders(PathArray, differed, MainFolder);

	        return differed.promise;
	    };

	    var checkForFolderCreationComplete = function (PathArr, differed, MainFolder) {
	        if (PathArr.length > 0) {
	            CreateFolders(PathArr, differed, MainFolder);
	        }
	        else {
	            differed.resolve('success');
	        }
	    }

	    var CreateFolders = function (PathArr, differed, MainFolder) {

	        
	        if (PathArr.length > 0) {
	            var item = PathArr.splice(0, 1);
	            var url = Config['BaseUrl'] + "/_api/Web/Folders/add('" + (MainFolder + item) + "')";
	            if (Config.UseAPIForSPCall) {
	                return this.updateThroughAPI(url, 'POST');
	            }
	            $.ajax({
	                url: url,
	                type: 'POST',
                    async:false,
	                contentType: 'application/json;odata=verbose',
	                headers: {
	                    'Accept': 'application/json;odata=verbose',
	                    'content-type': 'application/json;odata=verbose',
	                    'X-RequestDigest': $('#__REQUESTDIGEST').val()
	                },
	                success: function (data) {
	                    checkForFolderCreationComplete(PathArr, differed, MainFolder);
	                    
	                },
	                error: function () {
	                    checkForFolderCreationComplete(PathArr, differed, MainFolder);
	                }
	            });

	        }
	        else {
	            checkForFolderCreationComplete(PathArr, differed, MainFolder);
	        }	        
	      
	    };



	    return {
	        'updateThroughAPI': updateThroughAPI,
	        'CreateFolder': CreateFolder,
	        'CreateSubFolder': CreateSubFolder,
	        'CreateFolders': CreateFolders,
	        'CreateFolderByPath': CreateFolderByPath
	    };
	}]);
})();