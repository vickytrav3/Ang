﻿"use strict";
(function () {
    angular.module(Config['AppName'])
		.factory("Badges", ["baseSvc", "DAL", function ($baseService, DAL) {
		    var updateAllBadges = function () {
		        if (Global.CurrentUser.Role.indexOf(Constant.Role.Executive ) != -1  || Global.CurrentUser.Role.indexOf(Constant.Role.TL) ==-1) {
		            DAL.getAllNewRequest().then(function (response) {
		                if (response.value.length > 0) {
		                    $('#newRequestBadge').text(response.value.length);
		                }
		                else
		                    $('#newRequestBadge').text(0);
		            });
		        }
		        DAL.getAllMyTask(_spPageContextInfo.userId).then(function (response) {
		           
		            if (response.value.length > 0) {
		                $('#myActionBadge').text(response.value.length);
		            }
		            else
		                $('#myActionBadge').text(0);
		        });
		        if (Global.CurrentUser.Role.indexOf(Constant.Role.Executive) !=-1 || Global.CurrentUser.Role.indexOf(Constant.Role.TL) !=-1) {
		            DAL.getAllMyWork(_spPageContextInfo.userId, Global.CurrentUser.Role).then(function (response) {
		                if (response.value.length > 0) {
		                    $('#openQueriesBadge').text(response.value.length);
		                }
		                else
		                    $('#openQueriesBadge').text(0);
		            });
		        }
		        DAL.getAllTaskByStatus(_spPageContextInfo.userId, Constant.QueryStatus.Completed).then(function (response) {
		            if (response.value.length > 0) {
		                $('#respondedQueriesBadge').text(response.value.length);
		            }
		            else
		                $('#respondedQueriesBadge').text(0);
		        });
		        DAL.getAllTaskByStatus(_spPageContextInfo.userId, Constant.QueryStatus.Rejected).then(function (response) {
		            if (response.value.length > 0) {
		                $('#rejectedQueriesBadge').text(response.value.length);
		            }
		            else
		                $('#rejectedQueriesBadge').text(0);
		        });
		        DAL.getAllTaskByStatus(_spPageContextInfo.userId, Constant.QueryStatus.Invalid).then(function (response) {
		            if (response.value.length > 0) {
		                $('#invalidQueriesBadge').text(response.value.length);
		            }
		            else
		                $('#invalidQueriesBadge').text(0);
		        });
		    };

		    return {
		        updateAllBadges: updateAllBadges
		}

		}]);
})();


