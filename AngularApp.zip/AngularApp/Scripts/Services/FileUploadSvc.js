﻿"use strict";
(function () {
    angular.module(Config['AppName'])
	.factory("FileUploadSvc", ["$q", "$http", function ($q, $http) {
	    var hostWebUrl = Config['BaseUrl'];
	    var serverRelativeUrlToFolder = '';
	    var fileBase64 = "";
	    var fileObject = null;
	    var _isOnDMS = false;
	    var _skipAPICall = false;

	    var FileUpload = function (DocLibName, filePath, fileName, isOnDMS, skipAPICall) {
	        if (isOnDMS == undefined)
	            isOnDMS = false;
	        _isOnDMS = isOnDMS;
	        _skipAPICall = skipAPICall == undefined ? false : skipAPICall;

	        if (isOnDMS)
	            hostWebUrl = Config['BaseUrl']+"/DMS/";
	        var fileDeferred = $q.defer();
	        serverRelativeUrlToFolder = DocLibName;
	        if (filePath == undefined || filePath == '') {
	            fileDeferred.reject("error");
	        }
	        else {
	            var getFile = getFileBuffer(filePath);

	            getFile.done(function (arrayBuffer) {
	                //fileBase64 = base64ArrayBuffer(arrayBuffer);
	                // Add the file to the SharePoint folder.
	                var addFile = addFileToFolder(arrayBuffer, fileName);

	                if (Config.UseAPIForSPCall && !_skipAPICall) {
	                    addFile.then(function (response) {
	                        if (response.d.ListItemAllFields == undefined) {
	                            fileDeferred.reject("error");
	                            return;
	                        }
	                        var getItem = getListItem(response.d.ListItemAllFields.__deferred.uri);
	                        getItem.then(function (result) {
	                            fileObject = result.d;
	                            fileDeferred.resolve(result.d);
	                            //callBackFunction(listItem.d.ID);
	                        });
	                    }).catch(function (err) {
	                        fileDeferred.reject("error");
	                    });

	                } else {

	                    addFile.done(function (file, status, xhr) {
	                        // Get the list item that corresponds to the uploaded file.
	                        var getItem = getListItem(file.d.ListItemAllFields.__deferred.uri);
	                        getItem.done(function (listItem, status, xhr) {
	                            fileObject = listItem.d;
	                            fileDeferred.resolve(listItem.d);
	                            //callBackFunction(listItem.d.ID);
	                        });
	                        getItem.fail(onError);
	                    });
	                    addFile.fail(onError);

	                    getFile.fail(onError);
	                }

	            });
	        }
	        return fileDeferred.promise;
	    };

	    // Get the local file as an array buffer.
	    function getFileBuffer(filePath) {
	        var deferred = $.Deferred();
	        var reader = new FileReader();
	        reader.onloadend = function (e) {
	            deferred.resolve(e.target.result);
	        }
	        reader.onerror = function (e) {
	            deferred.reject(e.target.error);
	        }
	        if (Config.UseAPIForSPCall && !_skipAPICall)
	            reader.readAsDataURL(filePath);
            else
	            reader.readAsArrayBuffer(filePath);
	        return deferred.promise();
	    }

	    // Add the file to the file collection in the Shared Documents folder.
	    function addFileToFolder(arrayBuffer, fileName) {

	        // Get the file name from the file input control on the page.
	        //var parts = filePath.value.split('\\');

	        //$scope.fileExtension = fileName.split('.')[1];
	        // Construct the endpoint.
	        var fileCollectionEndpoint = String.format(
                "{0}/_api/web/getfolderbyserverrelativeurl('{1}')/files" +
                "/add(overwrite=true, url='{2}')",
                hostWebUrl, serverRelativeUrlToFolder, fileName);

	        if (Config.UseAPIForSPCall && !_skipAPICall) {
	            return updateThroughAPI(fileCollectionEndpoint, 'FileUpload', arrayBuffer);
	        }

	        // Send the request and return the response.
	        // This call returns the SharePoint file.
	        var headers = {
	            "accept": "application/json;odata=verbose",
	            "X-RequestDigest": $("#__REQUESTDIGEST").val()
	            //,"content-length": arrayBuffer.byteLength
	        }
	        if (!_isOnDMS)
	            headers["content-length"] = arrayBuffer.byteLength;

	        return $.ajax({
	            url: fileCollectionEndpoint,
	            type: "POST",
	            data: arrayBuffer,
	            processData: false,
	            headers: headers
	        });
	    }

	    function GetNewFileName() {
	        var fileName = "";
	        fileName = Global.CurrentUser.Info.Id + "_";
	        var date = new Date();
	        var components = [
                date.getYear(),
                date.getMonth(),
                date.getDate(),
                date.getHours(),
                date.getMinutes(),
                date.getSeconds(),
                date.getMilliseconds()
	        ];

	        fileName += components.join("");
	        return fileName;
	    }
	    function getListItem(fileListItemUri) {
	        //if (Config.UseAPIForSPCall && !_skipAPICall) {
	        //    return updateThroughAPI(fileListItemUri, 'GET');
	        //}
	        // Send the request and return the response.
	        return $.ajax({
	            url: fileListItemUri,
	            type: "GET",
	            headers: { "accept": "application/json;odata=verbose" }
	        });
	    }
	    function onError(err) {
	        //deferred.resolve("error: "+ JSON.stringify(err));
	    }

	    var updateThroughAPI = function (url, action, data) {
	        var model = {
	            Url: url,
	            Action: action
	        }
	        if (data == undefined || data == null) {
	            data = {};
	        }

	        if (typeof data == 'string')
	            model["Data"] = data;
	        else {
	            //data["UpdatedById"] = _spPageContextInfo.userId;
	            model["Data"] = "";//JSON.stringify(data);
	        }
	            

	        var deferred = $q.defer();
	        $http({
	            url: Config['BaseAPIUrl'] + 'SPRequest/Process',
	            method: "POST",
	            headers: {
	                "accept": "application/json;odata=verbose",
	                "timeout":90000,
	                "content-Type": "application/json;odata=verbose"
	            },
	            data: model
	        })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (result, status) {
                deferred.reject(result);
            });
	        return deferred.promise;
	    };

	    return {
	        'FileObject':fileObject,
	        'FileUpload': FileUpload,
	        'GetNewFileName': GetNewFileName,
	        'updateThroughAPI': updateThroughAPI
	    };
	}]);
})();