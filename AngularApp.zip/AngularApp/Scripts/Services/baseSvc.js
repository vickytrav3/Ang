﻿"use strict";
(function () {
    angular.module(Config['AppName'])
        .factory("baseSvc", ["$http", "$q", function ($http, $q) {

            var getRequest = function (query) {

                //if (query.indexOf(Config.ListEndPoint) != -1 || query.indexOf(Config.DMSListEndPoint) != -1) {
                //    if (Config.UseAPIForSPCall) {
                //        return this.updateThroughAPI(Config['BaseUrl'] + query, 'GET');
                //    }
                //}


                var deferred = $q.defer();

                $http({
                    method: 'GET',
                    url: Config['BaseUrl'] + query
                })
                .success(function (result) {
                    deferred.resolve(result);
                })
                .error(function (result, status) {
                    deferred.reject(status);
                });
                return deferred.promise;
            };
            var postRequest = function (data, url) {
                if (url.indexOf(Config.ListEndPoint) != -1 || url.indexOf(Config.DMSListEndPoint) != -1) {
                    if (Config.UseAPIForSPCall) {
                        return this.updateThroughAPI(Config['BaseUrl'] + url, 'POST', data);
                    }
                }


                var deferred = $q.defer();
                $http({
                    url: Config['BaseUrl'] + url,
                    method: "POST",
                    headers: {
                        "accept": "application/json;odata=verbose",
                        "X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
                        "content-Type": "application/json;odata=verbose"
                    },
                    data: JSON.stringify(data)
                })
                    .success(function (result) {
                        deferred.resolve(result);
                    })
                    .error(function (result, status) {
                        deferred.reject(result);
                    });
                return deferred.promise;
            };

            var updateRequest = function (data, url) {
                if (Config.UseAPIForSPCall) {
                    return this.updateThroughAPI(Config['BaseUrl'] + url, 'UPDATE', data);
                }

                var deferred = $q.defer();
                $http({
                    url: Config['BaseUrl'] + url,
                    method: "PATCH",
                    headers: {
                        "accept": "application/json;odata=verbose",
                        "X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
                        "content-Type": "application/json;odata=verbose",
                        "X-Http-Method": "PATCH",
                        "If-Match": "*"
                    },
                    data: JSON.stringify(data)
                })
                    .success(function (result) {
                        deferred.resolve(result);
                    })
                    .error(function (result, status) {
                        deferred.reject(result);
                    });
                return deferred.promise;
            };
            var deleteRequest = function (url) {
                if (Config.UseAPIForSPCall) {
                    return this.updateThroughAPI(Config['BaseUrl'] + url, 'DELETE');
                }

                var deferred = $q.defer();
                $http({
                    url: Config['BaseUrl'] + url,
                    method: "DELETE",
                    headers: {
                        "accept": "application/json;odata=verbose",
                        "X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
                        "IF-MATCH": "*"
                    }
                })
                    .success(function (result) {
                        deferred.resolve(result);
                    })
                    .error(function (result, status) {
                        deferred.reject(result);
                    });
                return deferred.promise;
            };

            var postRequestAPI = function (url, data) {
                var deferred = $q.defer();
                $http({
                    url: Config['BaseAPIUrl'] + url,
                    method: "POST",
                    headers: {
                        "accept": "application/json;odata=verbose",
                        "content-Type": "application/json;odata=verbose"
                    },
                    data: JSON.stringify(data)
                })
                    .success(function (response) {
                        deferred.resolve(response);
                    })
                    .error(function (result, status) {
                        deferred.reject(result);
                    });
                return deferred.promise;
            };

            var getUserInfoByEmailId = function (email) {

                var deferred = $q.defer();

                var getInfoFromEnsureUser = function () {
                    var data = {
                        logonName: 'i:0#.f|membership|' + email.trim()
                    };
                    var url = "/_api/web/ensureuser"

                    $http({
                        url: Config['BaseUrl'] + url,
                        method: "POST",
                        headers: {
                            "accept": "application/json;odata=verbose",
                            "X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
                            "content-Type": "application/json;odata=verbose"
                        },
                        data: JSON.stringify(data)
                    })
                    .success(function (result) {
                        if (result.d.Id != undefined && result.d.Id != null) {
                            var model = {
                                Id: result.d.Id,
                                Email: result.d.Email,
                                Title: result.d.Title,
                                Name: result.d.Title
                            };
                            deferred.resolve(model);
                        }
                        else
                            deferred.reject(null);
                    })
                    .error(function (result, status) {
                        deferred.reject(null);
                    });

                };

                //finding information using site user
                var query = Config['SiteUserEndPoint'] + "?$select=*&$filter=Email eq '" + email.trim() + "'";
                $http({
                    method: 'GET',
                    url: Config['BaseUrl'] + query
                })
                .success(function (result) {
                    if (result.value.length > 0 && result.value[0].Id != undefined) {
                        var model = {
                            Id: result.value[0].Id,
                            Email: result.value[0].Email,
                            Title: result.value[0].Title,
                            Name: result.value[0].Title
                        };
                        deferred.resolve(model);
                    }
                    else
                        getInfoFromEnsureUser();

                })
                .error(function (result, status) {
                    getInfoFromEnsureUser();
                    //deferred.reject(status);
                });

                return deferred.promise;
            };

            var updateThroughAPI = function (url, action, data) {
                var model = {
                    Url: url,
                    Action: action
                }
                if (data == undefined || data == null) {
                    data = {};
                }

                data["UpdatedById"] = _spPageContextInfo.userId;
                model["Data"] = JSON.stringify(data);

                var deferred = $q.defer();
                $http({
                    url: Config['BaseAPIUrl'] + 'SPRequest/Process',
                    method: "POST",
                    headers: {
                        "accept": "application/json;odata=verbose",
                        "content-Type": "application/json;odata=verbose"
                    },
                    data: model
                })
                    .success(function (response) {
                        var returnModel = {
                            d: {
                                value: []
                            }

                        }

                        if (response.d == undefined) {
                            deferred.resolve(returnModel);
                            return;
                        }
                        if (response.d.results != undefined) {

                            if (response.d.results.length > 0) {
                                for (var i = 0; i < response.d.results.length; i++) {
                                    response.d.results[i].ID = response.d.results[i].Id;
                                }
                            }
                            returnModel.d.value = response.d.results;
                            deferred.resolve(returnModel);
                        } else {
                            if (response.d.Id != undefined) {
                                response.d.ID = response.d.Id;
                            }
                            deferred.resolve(response);
                        }
                    })
                    .error(function (result, status) {
                        deferred.reject(result);
                    });
                return deferred.promise;
            };

            var downloadFile = function (url, returnObject) {
                if (returnObject == undefined)
                    returnObject = false;

                var model = {
                    Url: url,
                    Action: 'Download'
                }
                var deferred = $q.defer();
                $http({
                    url: Config['BaseAPIUrl'] + 'SPRequest/Process',
                    method: "POST",
                    headers: {
                        "accept": "application/json;odata=verbose",
                        "content-Type": "application/json;odata=verbose"
                    },
                    data: model
                })
                .success(function (response) {
                    deferred.resolve(response);
                    if (!returnObject) {
                        downloadBase64File(response);
                    }

                })
                .error(function (result, status) {
                    deferred.reject(null);
                    if (!returnObject)
                        alert("File could not be download.");

                });
                return deferred.promise;
            }

            return {
                getRequest: getRequest,
                postRequest: postRequest,
                updateRequest: updateRequest,
                deleteRequest: deleteRequest,
                postRequestAPI: postRequestAPI,
                getUserInfoByEmailId: getUserInfoByEmailId,
                updateThroughAPI: updateThroughAPI,
                downloadFile: downloadFile
            };
        }])
        .service('fileUpload', ['$http', function ($http) {
            this.uploadFileToUrl = function (file, uploadUrl) {
                var fd = new FormData();
                fd.append('file', file);
                $http.post(Config['BaseUrl'] + uploadUrl, fd, {
                    transformRequest: angular.identity,
                    headers: { 'Content-Type': undefined }
                })
                .success(function () {
                })
                .error(function () {
                });
            }
        }])
    ;
})();