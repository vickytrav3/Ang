﻿"use strict";
(function () {
    angular.module(Config['AppName'])
	.factory("EmailSvc", ["$q", "$http", function ($q, $http) {

	    var SendEmail = function (body, toUsers, ccUsers, subject) {
	        var data = {
	            body: body,
	            toUsers: toUsers.join(','),
	            ccUsers: ccUsers.join(','),
	            subject: subject
	        }
	        var differed = $q.defer();
	        
	        var url = Config['BaseAPIUrl'] + 'Email/Send';

	        $http({
	            url: url,
	            method: "POST",
	            headers: {
	                "accept": "application/json;odata=verbose",
	                "content-Type": "application/json;odata=verbose"
	            },
	            data: JSON.stringify(data)
	        })
                .success(function (response) {
                    differed.resolve(response);
                })
                .error(function (result, status) {
                    differed.reject(result);
                });

	        //var body = body;
	        //var from = Global.CurrentUser.Info.Email;
	        //var urlTemplate = Config['BaseUrl'] + "/_api/SP.Utilities.Utility.SendEmail";
	        //$.ajax({
	        //    contentType: 'application/json',
	        //    url: urlTemplate,
	        //    type: "POST",
	        //    data: JSON.stringify({
	        //        'properties': {
	        //            '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
	        //            'From': from,
	        //            'To': { 'results': toUsers },
	        //            'CC': { 'results': ccUsers },
	        //            'Body': body,
	        //            'Subject': subject
	        //        }
	        //    }
	        //  ),
	        //    headers: {
	        //        "Accept": "application/json;odata=verbose",
	        //        "content-type": "application/json;odata=verbose",
	        //        "X-RequestDigest": $("#__REQUESTDIGEST").val()
	        //    },
	        //    success: function (data) {
	        //        differed.resolve('success');
	        //    },
	        //    error: function (err) {
	        //        differed.resolve("error");
	        //    }
	        //});
	        return differed.promise;
	    };

	    var SPSendEmail = function (body, toUsers, ccUsers, subject) {
	        
	        var differed = $q.defer();

	        var from = Global.CurrentUser.Info.Email;
	        var urlTemplate = Config['BaseUrl'] + "/_api/SP.Utilities.Utility.SendEmail";
	        $.ajax({
	            contentType: 'application/json',
	            url: urlTemplate,
	            type: "POST",
	            data: JSON.stringify({
	                'properties': {
	                    '__metadata': { 'type': 'SP.Utilities.EmailProperties' },
	                    'From': from,
	                    'To': { 'results': toUsers },
	                    'CC': { 'results': ccUsers },
	                    'Body': body,
	                    'Subject': subject
	                }
	            }
	          ),
	            headers: {
	                "Accept": "application/json;odata=verbose",
	                "content-type": "application/json;odata=verbose",
	                "X-RequestDigest": $("#__REQUESTDIGEST").val()
	            },
	            success: function (data) {
	                differed.resolve('success');
	            },
	            error: function (err) {
	                differed.resolve("error");
	            }
	        });
	        return differed.promise;
	    };

	    return {
	        'SendEmail': SendEmail,
	        'SPSendEmail': SPSendEmail
	    };
	}]);
})();