function setErrorOnControl(selector, message) {
    $(selector).addClass("border-on-error");
    //$(selector).after("<span class='error'>" + message + "</span>");
}

function removeErrorFromControl(selector) {
    $(selector).removeClass("border-on-error");
    if ($(selector).next().is('span'))
        $(selector).next().remove();
}

function validateInputControl(selector) {
    var foundError = false;
    if ($(selector).val() == undefined || $(selector).val().trim() == "") {
        setErrorOnControl(selector, "*")
        foundError = true
    }
    else {
        removeErrorFromControl(selector);
    }
    return !foundError;

}

function validateInputForDigitsOnly(selector) {
    var foundError = false;
    if (isNaN($(selector).val())) {
        setErrorOnControl(selector, "*");
        //setErrorOnControl(selector, "Only digits allowed.");
        foundError = true
    }
    else {
        removeErrorFromControl(selector);
    }
    return !foundError;

}


function validateEachInputControl(selector) {
    var foundError = false;
    $(selector).each(function () {
        if (!foundError)
            foundError = !validateInputControl(this);
        else
            validateInputControl(this);
    });
    return !foundError;
}

function validateInputEmail(selector) {
    var foundError = false;
    if ($(selector).val() !== undefined || $(selector).val().trim() !== "") {
        filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (filter.test($(selector).val())) {
            removeErrorFromControl(selector);
        }
        else {
            setErrorOnControl(selector, "*");
            //setErrorOnControl(selector, "Invalid Email.");
            foundError = true
        }

    }
    else {
        removeErrorFromControl(selector);
    }
    return !foundError;

}

function CompareControls(selector1, selector2) {
    var foundError = false;

    if ($(selector1).val() != $(selector2).val()) {
        var errorMsg = $(selector1).attr('compare-message');
        if (errorMsg === undefined || errorMsg == '')
            errorMsg = '*';
        //errorMsg = 'Value must be match with above field value.';
        setErrorOnControl(selector1, errorMsg);
        foundError = true
    }
    else {
        removeErrorFromControl(selector1);
    }
    return !foundError;
}

function DateCompare(selector1, selector2) {
    var foundError = false;
    var date1 = new Date($(selector1).val());
    var date2 = new Date($(selector2).val());
    if (date1 < date2) {
        var errorMsg = $(selector1).attr('compare-message');
        if (errorMsg === undefined || errorMsg == '')
            errorMsg = '*';
        //errorMsg = 'Invalid date range.';
        setErrorOnControl(selector1, errorMsg);
        foundError = true
    }
    else {
        removeErrorFromControl(selector1);
    }
    return !foundError;
}


function ValidateRegEx(selector) {
    var foundError = false;

    var regEx = $(selector).attr('validate-regex');

    if (regEx !== undefined && regEx.trim() != '') {
        regEx = regEx.trim();
        regEx = new RegExp(regEx);
        if (!regEx.test($(selector).val())) {
            var errorMsg = $(selector).attr('regex-message');
            if (errorMsg === undefined || errorMsg == '')
                errorMsg = '*';
            //errorMsg = 'Invalid Entry';
            setErrorOnControl(selector, errorMsg)
            foundError = true
        }
        else {
            removeErrorFromControl(selector);
        }
    }
    return !foundError;
}


function validateSelectControl(selector) {
    var foundError = false;

    if ($(selector).val() == undefined || $(selector).val() == "" || $(selector).val() == "0") {
        setErrorOnControl(selector, "*")
        foundError = true
    }
    else {
        removeErrorFromControl(selector);
    }
    return !foundError;
}

function IsGreaterThanZero(selector) {
    var foundError = false;
    if ($(selector).val() != undefined && $(selector).val() != "") {
        try {
            var num = parseInt($(selector).val());
            if (num <= 0) {
                setErrorOnControl(selector, "*");
                //setErrorOnControl(selector, "Please enter value greater than zero.")
                foundError = true;
            }
            else {
                removeErrorFromControl(selector);
            }
        }
        catch (ex) {

        }
    }
    return !foundError;
}


function validateInputRange(selector) {
    var foundError = false;
    var arr = $(selector).attr('input-range').trim().split(',');
    if (arr.length == 2) {
        try {
            var val1 = parseInt(arr[0].trim());
            var val2 = parseInt(arr[1].trim());
            if ($(selector).val().length >= val1 && $(selector).val().length <= val2) {
                removeErrorFromControl(selector);
            }
            else {
                //var errorMsg = $(selector).attr('range-message');
                //if (errorMsg === undefined || errorMsg == '')
                    errorMsg = '*';
                //errorMsg = 'Invalid range. Should be ' + val1 + '-' + val2 + ' characters.';
                setErrorOnControl(selector, errorMsg);
                foundError = true
            }
        }
        catch (ex) {

        }
    }
    return !foundError;
}


function ValidateIPaddress(selector) {
    var foundError = false;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

    if ($(selector).val() == undefined || $(selector).val() == "" || !selector.value.match(ipformat)) {
        setErrorOnControl(selector, "*");
        //setErrorOnControl(selector, "Invalid IP Address.")
        foundError = true
    }
    else {
        removeErrorFromControl(selector);
    }
    return !foundError;
}

function ValidateContainingControls(containerId) {
    var isErrorFound = false;
    $('span.error').remove();
    $.each($('#' + containerId + ' input[validate]:visible'), function (i, element) {
        var isValid = true;
        var validate = $(element).attr('validate').split(' ');
        for (var i = 0; i < validate.length; i++) {
            if (!$(element).next().is('span.error')) { // validate if no previous error
                if (validate[i].toLowerCase() == 'required') {
                    isValid = validateInputControl(element);
                }
                else if (validate[i].toLowerCase() == 'email') {
                    if (isValid) {
                        isValid = validateInputEmail(element);
                    }
                }
                else if (validate[i].toLowerCase() == 'digits') {
                    if (isValid) {
                        isValid = validateInputForDigitsOnly(element);
                    }
                }
                else if (validate[i].toLowerCase() == 'ipaddress') {
                    if (isValid) {
                        isValid = ValidateIPaddress(element);
                    }
                }
                else if (validate[i].toLowerCase() == 'gt0') {
                    if (isValid) {
                        isValid = IsGreaterThanZero(element);
                    }
                }

                if (!isErrorFound)
                    isErrorFound = !isValid;
            }
        }

    });

    $.each($('#' + containerId + ' input[input-range]:visible'), function (i, element) {
        if (!$(element).next().is('span.error')) { // validate if no previous error
            if (!isErrorFound)
                isErrorFound = !validateInputRange(element);
            else
                validateInputRange(element);
        }
    });

    $.each($('#' + containerId + ' input[compare-with]:visible'), function (i, element) {
        if (!$(element).next().is('span.error')) { // validate if no previous error
            var compareWith = $(element).attr('compare-with');
            if (!isErrorFound)
                isErrorFound = !CompareControls(element, compareWith);
            else
                CompareControls(element, compareWith);
        }
    });

    $.each($('#' + containerId + ' input[compare-date-with]:visible'), function (i, element) {
        if (!$(element).next().is('span.error')) { // validate if no previous error
            var compareWith = $(element).attr('compare-date-with');
            if (!isErrorFound)
                isErrorFound = !DateCompare(element, compareWith);
            else
                DateCompare(element, compareWith);
        }
    });

    $.each($('#' + containerId + ' input[validate-regex]:visible'), function (i, element) {
        if (!$(element).next().is('span.error')) { // validate if no previous error
            if (!isErrorFound)
                isErrorFound = !ValidateRegEx(element);
            else
                ValidateRegEx(element);
        }
    });

    $.each($('#' + containerId + ' textarea[validate]:visible'), function (i, element) {
        var validate = $(element).attr('validate').split(' ');
        for (var i = 0; i < validate.length; i++) {
            if (validate[i].toLowerCase() == 'required') {
                if (!isErrorFound)
                    isErrorFound = !validateInputControl(element);
                else
                    validateInputControl(element);
            }
        }

    });

    $.each($('#' + containerId + ' select[validate]:visible'), function (i, element) {
        //if (!$(element).hasClass('ng-hide')) {
        var validate = $(element).attr('validate').split(' ');
        for (var i = 0; i < validate.length; i++) {
            if (validate[i].toLowerCase() == 'required') {
                if ($(element).is('select'))
                    if (!isErrorFound)
                        isErrorFound = !validateSelectControl(element);
                    else
                        validateSelectControl(element);
            }
            //}
        }
    });
    return !isErrorFound;
}

function isDate(txtDate) {
    var currVal = (dateFormat(new Date(txtDate), 'dd/mm/yyyy'));
    //var currVal = txtDate;
    if (currVal == '')
        return false;

    //Declare Regex  
    var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var dtArray = currVal.match(rxDatePattern); // is format OK?

    if (dtArray == null)
        return false;

    //Checks for mm/dd/yyyy format.
    dtDay = dtArray[1];
    dtMonth = dtArray[3];
    dtYear = dtArray[5];

    if (dtMonth < 1 || dtMonth > 12)
        return false;
    else if (dtDay < 1 || dtDay > 31)
        return false;
    else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31)
        return false;
    else if (dtMonth == 2) {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay > 29 || (dtDay == 29 && !isleap))
            return false;
    }
    return true;
}



function clearDate(evt) {
    $("#" + evt.currentTarget.id).val('');
    return false;
}