var Config = {
    "AppName": "AngularApp",
    // "BaseUrl": '/sites/AngularApp/',
    // "BaseAPIUrl": "",
    "TemplateBaseUrl": 'Views/'
    // "ListEndPoint": '_api/web/lists',
    // "DMSListEndPoint": 'DMS/_api/web/lists',
    // "GroupEndPoint": '_api/web/sitegroups',
    // "SiteUserEndPoint": '_api/web/siteusers',
    // "EnsureUser": "_api/web/ensureuser",
    // "UserProfileEndPoint": '_api/SP.UserProfiles.PeopleManager',
    // "DisplayDateFormat": "dd a, yyyy",
    // "StandardDateFormat": "yyyy-MM-dd",
    // "DisplayDateTimeFormat": "dd a, yyyy hh:mm:ss tt",
    // "StandardDateTimeFormat": "yyyy/MM/dd hh:mm:ss tt",
    // "WebLinkForEmail": "",
    // "UseAPIForSPCall":false,
    // "MainFolder": "EmployeeDoc"
};


var Constant = {
    Roles: { Employee: 'Employee' },
    RolesDisplayName: {Employee: 'Employee'}
};

var Global = {
    CurrentUser: {
        IsLoggedIn: false, Info: {}, Roles: [], Departments: []
    },
    CurrentPage: '',
    EmailSignature: "<br/><a href=\"" + Config["WebLinkForEmail"] + "\">" + Config["WebLinkForEmail"] + "</a><br/><br/>",
    Style: {
        table: "style='border-collapse: collapse;margin-top:5px;border: 1px solid black; padding:5px;'",
        th: "style='border: 1px solid black; padding:5px;background:#0072c6;color:#fff;'",
        td: "style='border: 1px solid black; padding:5px;vertical-align:top;text-align:left;'",
        tdBold: "style='border: 1px solid black; padding:5px;font-weight:bold;vertical-align:top;text-align:left;'"
    },
    Pages: {
        Employee: [
            { Title: 'Dashboard', URL: 'Dashboard' }
        ]
    }
};