﻿"use strict";
(function () {
    angular.module(Config['AppName'])
		.controller("HomeCtrl", ["$scope", "$interval", "$routeParams", function ($scope, $interval,$routeParams){
    
      $scope.TArray = [{Name:"Vikram"},{Name:"Vikram"}];
      
    
    }]);
  
  })();