Array.prototype.sortBy = function (p) {
    return this.slice(0).sort(function (a, b) {
        return (a[p] > b[p]) ? 1 : (a[p] < b[p]) ? -1 : 0;
    });
}

Array.prototype.sortByDesc = function (p) {
    return this.slice(0).sort(function (a, b) {
        return (a[p] < b[p]) ? 1 : (a[p] > b[p]) ? -1 : 0;
    });
}

String.prototype.toTitleCase = function () {
    return (this.charAt(0).toUpperCase() + this.substr(1).toLowerCase());
}

String.prototype.toCamelCase = function () {
    var arr = this.split(' ');
    var result = '';
    for (var i = 0; i < arr.length; i++) {
        result += ' ' + (arr[i].charAt(0).toUpperCase() + arr[i].substr(1).toLowerCase())
    }
    return result.trim();
}


var getUniqueLevelEntries = function (obj) {
    var newObj = [];
    if (obj.length > 0) {
        var arr = [];
        for (var i = 0; i < obj.length; i++) {
            if (arr.indexOf(obj[i].ID) == -1) {
                newObj.push(obj[i]);
                arr.push(obj[i].ID);
            }
        }
    }
    return newObj;
}

var filterLevelByAccess = function (all, allowed) {
    var data = [];
    for (var i = 0; i < all.length; i++) {
        for (var j = 0; j < allowed.length; j++) {
            if (all[i].ID == allowed[j].ID)
                data.push(all[i]);
        }
    }
    return data;
}

function GetNewFileName() {
    var fileName = "";
    fileName = Global.CurrentUser.Info.Id + "_";
    var date = new Date();
    var components = [
        date.getYear(),
        date.getMonth(),
        date.getDate(),
        date.getHours(),
        date.getMinutes(),
        date.getSeconds(),
        date.getMilliseconds()
    ];

    fileName += components.join("");
    return fileName;
}

function redirectTo(page) {
    if (page == "")
        document.location.href = document.location.href.split('#')[0];
    else
        document.location.href = document.location.href.split('#')[0] + "#/" + page;
}

var GetCurrentPage = function () {
    if (window.location.href.indexOf('#/') != -1) {
        var currentPageName = window.location.href.split('#/')[1];
        if (currentPageName != undefined && currentPageName != "") {
            var index = currentPageName.indexOf('/')
            if (index != -1)
                currentPageName = currentPageName.substring(0, index);

            return currentPageName;
        }
    }
    return '';
}


var SetCurrentPage = function () {
    Global.CurrrentPage = GetCurrentPage();
};


var HasChildMenu = function (menu, parentId) {
    for (var i = 0; i < menu.length; i++) {
        if (menu[i].ParentId == parentId) {
            return true;
        }
    }
    return false;
}


var ShowLoader = function () {
    var width = (($(window).width() / 2 - $('#imgLoading').width() / 2));
    var height = (($(window).height() / 2 - $('#imgLoading').height() / 2)) - 50;
    $('#imgLoading').css('top', height + 'px');
    $('#imgLoading').css('left', width + 'px');
    $(".loading").show();
}

var HideLoader = function () {
    $(".loading").hide();
    $(document).scrollTop(0);
};

var moneyFormat = function (n) {
    return n.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
};

function TrimString(value) {
    if (typeof String.prototype.trim !== 'function') {
        return value.replace(/^\s+|\s+$/, '');
    }
    else
        return value.trim();
}

function GetHashPassword(password) {
    var value = TrimString(password);
    if (value != "") {
        var encryptedPswd = hex_md5(value);
        return encryptedPswd;
    }
    return value;
}
var fnExcelReport = function (obj, tableid, sheetName, fileName) {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (msie == -1)
        msie = ua.indexOf("Edge/");

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        tab_text = '<table border="1">' + $('#' + tableid).html() + "</table>";
        tab_text = tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
        tab_text = tab_text.replace(/<img[^>]*>/gi, ""); // remove if u want images in your table
        tab_text = tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

        txtArea1.document.open("txt/html", "replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus();
        sa = txtArea1.document.execCommand("SaveAs", true, fileName + ".xls");
    }
    else {
        //other browser not tested on IE 11
        //document.getElementById('aExportToExcel').click();
        return ExcellentExport.excel(obj, tableid, sheetName);
        //sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));
    }
    return false;
};

var FormatDateForQuery = function (x, y) {
    if (y === undefined)
        y = new Date();
    //y.setHours(y.getHours() - 5);
    //y.setMinutes(y.getMinutes() - 30);
    return FormatDate(x, y, true);
};

var FormatDate = function (x, y) {
    var twentyFour = true;
    if (x.indexOf('tt') != -1) {
        twentyFour = false;
        x = x.replace(/t+/g, '');
    }
    var day = new Array();
    day[0] = "Sunday";
    day[1] = "Monday";
    day[2] = "Tuesday";
    day[3] = "Wednesday";
    day[4] = "Thursday";
    day[5] = "Friday";
    day[6] = "Saturday";

    var month = new Array();
    month[0] = "January";
    month[1] = "February";
    month[2] = "March";
    month[3] = "April";
    month[4] = "May";
    month[5] = "Jun";
    month[6] = "July";
    month[7] = "August";
    month[8] = "September";
    month[9] = "October";
    month[10] = "November";
    month[11] = "December";

    if (y === undefined || y === null)
        y = new Date();
    if (y == 'Invalid Date')
        return '';

    var z = {
        a: month[y.getMonth()].substr(0, 3),
        A: month[y.getMonth()],
        M: y.getMonth() + 1,
        d: y.getDate(),
        h: y.getHours(),
        m: y.getMinutes(),
        s: y.getSeconds(),
        w: day[y.getDay()].substr(0, 3),
        W: day[y.getDay()]
    };
    var prim = '';
    if (!twentyFour) {
        if (x.indexOf(':') != -1) {
            prim = 'AM';
            if (z.h >= 12) {
                prim = 'PM';
                if (z.h > 12)
                    z.h -= 12;
            }
        }
    }

    x = x.replace(/(y+)/g, function (v) {
        return y.getFullYear().toString().slice(-v.length)
    });

    x = x.replace(/(M+|d+|h+|m+|s+)/g, function (v) {
        return ((v.length > 1 ? "0" : "") + eval('z.' + v.slice(-1))).slice(-2)
    });
    x = x.replace(/(MMM+)/g, function (v) {
        if (v.indexOf('a') != -1)
            return (eval('z.' + v.slice(-1))); //.slice(-2)
        else
            return ((v.length > 1 ? "0" : "") + eval('z.' + v.slice(-1))).slice(-2)
    });

    if (x.indexOf('a') != -1) {
        x = x.replace('a', function (v) {
            if (v.indexOf('a') != -1)
                return (eval('z.' + v.slice(-1)));
        });
    } else if (x.indexOf('A') != -1) {
        x = x.replace('A', function (v) {
            if (v.indexOf('A') != -1)
                return (eval('z.' + v.slice(-1)));
        });
    }

    x = x.replace(/ww+/g, z.w);
    x = x.replace(/WW+/g, z.W);
    x = x + prim;
    x = x.replace(/\s\s+/g, ' ');

    return x;
}

function getTimeIn24Hours(time) {
    try {
        if (time == null || time == '')
            return time;
        if (time.indexOf('M') != -1) {
            time = time.replace(/\s+/g, '').toLowerCase();
            time = time.replace('a', ' a');
            time = time.replace('p', ' p');
            time = FormatDate('hh:mm', new Date('1 Jan, 2000 ' + time));
        }
    } catch (ex) {

    }
    return time;
}

function getTimeIn12Hours(time) {
    try {
        if (time == null || time == '')
            return time;
        time = FormatDate('hh:mm tt', new Date('1 Jan, 2000 ' + time));
    } catch (ex) {

    }

    return time;
}


function limitText(limitField, limitCount, limitNum) {

    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    } else {
        $("#" + limitCount).val(limitNum - limitField.value.length);
    }
}

function isItemExist(arr, id) {
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].ID == id)
            return true;
    }
    return false;
}
var SetUserMenu = function () {
    $(document).ready(function () {
        //if (Global.CurrentUser.Roles.length > 0) {
        //    if (Global.CurrentUser.Roles.indexOf(Constant.Roles.Admin) != -1) {
        //        $('.admin').show();
        //    }
        //    else {
        //        $('.admin').hide();
        //    }

        //} else {
        //    redirectTo("AccessDenied");
        //}
    });
};

var reqCount = 0;

//function hasFoundRoles(setMenu) {
//    if (reqCount == 1) {
//        if (setMenu != undefined && setMenu == true) {
//            SetUserMenu();
//        }
//        return true;
//    }
//    return false;
//}

var foundUserRoles = false;
var counter = 0;

var checkForRoleCompletion = function () {
    if (counter >= 1) {
        foundUserRoles = true;

        var roles = Global.CurrentUser.Roles;
        $("#TopMenuUL").show();
        $("li.emp").hide();

        roles.filter(function (r) {
            if (r == Constant.Roles.Employee)
                $("li.emp").show();
        });
    }
}

var interval;
function IsPageAllowed(pageName) {
    clearInterval(interval);
    if (Global.CurrentUser.Roles.filter(function (item) { return item == Constant.Roles.Employee })[0] != undefined && Global.Pages.Employee.filter(function (item) { return item.URL == pageName })[0] != undefined)
        return true;
    else
        return true; //allowing all page to all users.
}

function base64ArrayBuffer(arrayBuffer) {
    var base64 = ''
    var encodings = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

    var bytes = new Uint8Array(arrayBuffer)
    var byteLength = bytes.byteLength
    var byteRemainder = byteLength % 3
    var mainLength = byteLength - byteRemainder

    var a, b, c, d
    var chunk

    // Main loop deals with bytes in chunks of 3
    for (var i = 0; i < mainLength; i = i + 3) {
        // Combine the three bytes into a single integer
        chunk = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2]

        // Use bitmasks to extract 6-bit segments from the triplet
        a = (chunk & 16515072) >> 18 // 16515072 = (2^6 - 1) << 18
        b = (chunk & 258048) >> 12 // 258048   = (2^6 - 1) << 12
        c = (chunk & 4032) >> 6 // 4032     = (2^6 - 1) << 6
        d = chunk & 63               // 63       = 2^6 - 1

        // Convert the raw binary segments to the appropriate ASCII encoding
        base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d]
    }

    // Deal with the remaining bytes and padding
    if (byteRemainder == 1) {
        chunk = bytes[mainLength]

        a = (chunk & 252) >> 2 // 252 = (2^6 - 1) << 2

        // Set the 4 least significant bits to zero
        b = (chunk & 3) << 4 // 3   = 2^2 - 1

        base64 += encodings[a] + encodings[b] + '=='
    } else if (byteRemainder == 2) {
        chunk = (bytes[mainLength] << 8) | bytes[mainLength + 1]

        a = (chunk & 64512) >> 10 // 64512 = (2^6 - 1) << 10
        b = (chunk & 1008) >> 4 // 1008  = (2^6 - 1) << 4

        // Set the 2 least significant bits to zero
        c = (chunk & 15) << 2 // 15    = 2^4 - 1

        base64 += encodings[a] + encodings[b] + encodings[c] + '='
    }

    return base64
}

function dataURItoBlob(dataURI, callback) {
    // convert base64 to raw binary data held in a string
    // doesn't handle URLEncoded DataURIs - see SO answer #6850276 for code that does this
    var byteString = atob(dataURI.split(',')[1]);

    // separate out the mime component
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]

    // write the bytes of the string to an ArrayBuffer
    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }

    // write the ArrayBuffer to a blob, and you're done
    var bb = new Blob([ab], {
        type: mimeString
    });
    return bb;
}


function refreshBootstrapSelect(selector) {
    if (selector == undefined)
        selector = '.selectpicker';
    setTimeout(function () {
        $(selector).selectpicker('refresh');
    }, 500);
}


function updateRequestDigest() {
    $.ajax({
        url: _spPageContextInfo.webAbsoluteUrl + "/_api/contextinfo",
        method: "POST",
        headers: { "Accept": "application/json; odata=verbose" },
        success: function (data) {
            document.getElementById("__REQUESTDIGEST").value = data.d.GetContextWebInformation.FormDigestValue;
            setTimeout(updateRequestDigest, 900000); //15 min
        },
        error: function (data, errorCode, errorMessage) {
            alert(errorMessage)
        }
    });
}
setTimeout(updateRequestDigest, 900000);//15 min


function setDatePicker(selector, customDate, minDate, maxDate, showMonthYearSelection, pickTime) {
    if (showMonthYearSelection == undefined)
        showMonthYearSelection = false;
    if (pickTime == undefined)
        pickTime = false;
    $(selector).click(function () {
        $(this).blur();
    });

    $(selector).focusin(function () {
        $(this).blur();
    });

    var options = {
        format: 'dd M, yyyy',
        viewMode: showMonthYearSelection ? 'years' : 'days',
        pickTime: false,
        startView: 'month',
        minView: 'month',
        autoclose: true
    }
    if (minDate != undefined && minDate != null)
        options.startDate = minDate;
    if (maxDate != undefined && maxDate != null)
        options.endDate = maxDate;

    // if (customDate != undefined && customDate != null)
    //     options.defaultDate = customDate;

    //$(selector).datetimepicker("destroy");
    $(selector).datetimepicker(options);

    if (customDate != undefined && customDate != null) {
        setTimeout(function () {
            $(selector).datetimepicker('setDate', customDate);
        }, 500);
    }

    //else
    //$(selector).datepicker('setDate', new Date());

    //if (!$(selector).hasClass('dp-control'))
    //    $(selector).addClass('dp-control');
}
jQuery(document).ready(function () {
    jQuery('.wrapper').width(jQuery(this).width() - 17);
    jQuery(window).on("resize", function () {
        jQuery('.wrapper').width(jQuery(this).width() - 17);
    });

});


//Dashboard settings start

// SET GLOBAL NAMESPACE = payU
var payU = window.payU || {};


function base64ToBlob(base64) {

    var binStr = atob(base64.split(',')[1]),
      len = binStr.length,
      arr = new Uint8Array(len),
      mimeString = base64.split(',')[0].split(':')[1].split(';')[0]

    for (var i = 0; i < len; i++) {
        arr[i] = binStr.charCodeAt(i);
    }

    return new Blob([arr], {
        type: mimeString
    });

}



function downloadBase64File(model) {
    if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > 0 || window.navigator.userAgent.indexOf("Edge") > -1) {
        $('#aDownloadFile').attr('href', 'javascript:void(0);');
        $('#aDownloadFile').attr('onclick', "javascript:window.navigator.msSaveBlob(dataURItoBlob('" + model.Base64 + "'), '" + model.FileName + "');")
    } else {
        var url = URL.createObjectURL(base64ToBlob(model.Base64));
        $('#aDownloadFile').attr('href', url);
        $('#aDownloadFile').attr('download', model.FileName);
    }
    document.getElementById('aDownloadFile').click();
}


function GetMonthInNumber(mon) {

    var d = Date.parse(mon + "1, 2012");
    if (!isNaN(d)) {
        return new Date(d).getMonth() + 1;
    }
    return -1;
}


//JS for menu
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
            dropdownContent.style.display = "none";
        } else {
            dropdownContent.style.display = "block";
        }
    });

}