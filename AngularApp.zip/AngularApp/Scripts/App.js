"use strict";
(function () {
    angular.module(Config['AppName'], ["ngRoute", "angular-table", "ngDialog", "ngSanitize"])
		.config(["$routeProvider", "ngDialogProvider", function ($routeProvider, ngDialogProvider) {
		    $routeProvider.when("/", {
		        templateUrl: Config['TemplateBaseUrl'] + "Home.html",
				controller: "HomeCtrl"
		    })
			.when("/Home", {
                templateUrl: Config['TemplateBaseUrl'] + "Home.html",
				controller: "HomeCtrl"
            });
		    //setting default setting for ngDialog
		    ngDialogProvider.setDefaults({
		        className: 'ngdialog-theme-default',
		        plain: false,
		        showClose: true,
		        closeByDocument: false,
		        closeByEscape: true,
		        appendTo: false
		    });

		}])
        .filter('startFrom', function () {
            return function (input, start) {
                if (input == undefined || input == [])
                    return [];
                start = +start; //parse to int
                return input.slice(start);
            }
        });

})();